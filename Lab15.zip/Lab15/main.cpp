#include <iostream>
#include "graphtype.h"
#include "graphtype.cpp"
using namespace std;

template<class VertexType>
int GraphType<VertexType> ::OutDegree(VertexType v){
    int res=0;
    for(int i=0;i<numVertices;i++){
        if(WeightIs(v,vertices[i])!=NULL_EDGE)
            res++;
    }
    return res;
}
template<class VertexType>
bool GraphType<VertexType> ::FoundEdge(VertexType fromVertex, VertexType toVertex){
    int row = IndexIs(vertices, fromVertex);
    int col= IndexIs(vertices, toVertex);
    if(edges[row][col]==1)
      return true;
    else
      return false;
}


int main(){

    GraphType<char> p;
    p.AddVertex('A');
    p.AddVertex('B');
    p.AddVertex('C');
    p.AddVertex('D');
    p.AddVertex('E');
    p.AddVertex('F');
    p.AddVertex('G');
    p.AddVertex('H');

    p.AddEdge('A','B',1);
    p.AddEdge('A','C',1);
    p.AddEdge('A','D',1);

    p.AddEdge('B','A',1);
    p.AddEdge('D','A',1);
    p.AddEdge('D','E',1);

    p.AddEdge('D','G',1);
    p.AddEdge('G','F',1);
    p.AddEdge('F','H',1);
    p.AddEdge('H','E',1);

    cout << p.OutDegree('D') <<endl;
    cout << p.FoundEdge('A','D') << endl;
    cout << p.FoundEdge('B','D') << endl;
    p.DepthFirstSearch('B','E');
    p.DepthFirstSearch('E','B');
    p.BreadthFirstSearch('B','E');
    p.BreadthFirstSearch('E','B');

    return 0;
}
